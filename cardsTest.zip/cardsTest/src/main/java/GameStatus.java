package main.java;

public class GameStatus {
	private volatile boolean gameWon = false;
    private volatile int winner = -1;

    public synchronized void declareWinner(int id) {
        if (!gameWon) {
            gameWon = true;
            winner = id;
        }
    }

    public boolean isGameWon() {
        return gameWon;
    }

    public int getWinner() {
        return winner;
    }

}
