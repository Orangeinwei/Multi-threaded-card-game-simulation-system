package main.java;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Player implements Runnable {
	private final int id;
    private final int preferredValue;
    private final List<Card> hand;
    private final Deck leftDeck;
    private final Deck rightDeck;
    private final PrintWriter writer;
    private final GameStatus gameStatus; // Shared object to track game over

    public Player(int id, Deck leftDeck, Deck rightDeck, PrintWriter writer, GameStatus gameStatus) {
        this.id = id;
        this.preferredValue = id; // as per spec: player i prefers i's
        this.hand = new ArrayList<>();
        this.leftDeck = leftDeck;
        this.rightDeck = rightDeck;
        this.writer = writer;
        this.gameStatus = gameStatus;
    }

    public void addCardToHand(Card card) {
    	if (card != null) { 
    		hand.add(card);
    	}
    }

    // Check if the player has the winning hand
    private boolean hasWinningHand() {
        if (hand.isEmpty()) return false;
        // First filter out all null cards
        List<Card> validCards = new ArrayList<>();
        for (Card card : hand) {
            if (card != null) {
                validCards.add(card);
            }
        }
        
        // Returns false if there are no valid cards
        if (validCards.isEmpty()) return false;
        
        // Check that all valid cards have the same value
        int firstValue = validCards.get(0).getValue();
        for (Card card : validCards) {
            if (card.getValue() != firstValue)
                return false;
        }
        return true;
    }

    // Randomly choose a non-preferred card
    private Card chooseCardToDiscard() {
        List<Card> nonPreferredCards = new ArrayList<>();
        for (Card card : hand) {
            if (card != null && card.getValue() != preferredValue) {
                nonPreferredCards.add(card);
            }
        }
        if (!nonPreferredCards.isEmpty()) {
            Random random = new Random();
            int randomIndex = random.nextInt(nonPreferredCards.size());
            return nonPreferredCards.get(randomIndex);
        } else if (!hand.isEmpty()) {
            // All cards are preferred, so discard the first one.
            return hand.get(0);
        } else {
            //  when cards in hands are empty
            throw new IllegalStateException("Cannot discard from empty hand");
        }
    }

    private String handToString() {
        StringBuilder sb = new StringBuilder();
        for (Card card : hand) {
        	if (card != null) { 
        		sb.append(card.getValue()).append(" ");
        	} else {
        		sb.append("null ");
        	}
        }
        return sb.toString().trim();
    }

    @Override
    public void run() {
        // Log initial hand
        writer.println("player " + id + " initial hand " + handToString());
        writer.flush();

        // Immediate win check
        synchronized (gameStatus) {
	        if (hasWinningHand() && !gameStatus.isGameWon()) {
	            writer.println("player " + id + " wins");
	            writer.println("player " + id + " exits");
	            writer.println("player " + id + " final hand: " + handToString());
	            writer.flush();
	            System.out.println("player " + id + " wins");
	            gameStatus.declareWinner(id);
	            return;
	        }
        }

        // Main game loop
        while (!gameStatus.isGameWon()) {
            // To ensure the draw+discard is atomic, lock both decks in a fixed order: (for last player, left deck id > right)
            // The other players can't use the Deck until this player turn is finished (draw+discard)
            Deck firstLock = (leftDeck.getId() < rightDeck.getId()) ? leftDeck : rightDeck;
            Deck secondLock = (firstLock == leftDeck) ? rightDeck : leftDeck;

            firstLock.getLock().lock();
            secondLock.getLock().lock();
            try {
                // Draw from left deck
                Card drawnCard = leftDeck.drawCard();
                writer.println("player " + id + " draws a " + drawnCard + " from deck " + leftDeck.getId());
                hand.add(drawnCard);

                // Choose a card to discard
                Card cardToDiscard = chooseCardToDiscard();
                hand.remove(cardToDiscard);
                rightDeck.addCard(cardToDiscard);
                writer.println("player " + id + " discards a " + cardToDiscard + " to deck " + rightDeck.getId());
                writer.println("player " + id + " current hand is " + handToString());
                writer.flush();
            } finally {
                secondLock.getLock().unlock();
                firstLock.getLock().unlock();
            }

            // Check for win condition
            synchronized (gameStatus) {
	            if (hasWinningHand() && !gameStatus.isGameWon()) {
	                writer.println("player " + id + " wins");
	                writer.println("player " + id + " exits");
	                writer.println("player " + id + " final hand: " + handToString());
	                writer.flush();
	                System.out.println("player " + id + " wins");
	                gameStatus.declareWinner(id);
	                break;
	            }
            }

            // Small sleep to yield control (this is optional, can be commented out)
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                // Handle interruption if needed....
            }
        }

        // If game has been won by another player, log exit details
        if (gameStatus.getWinner() != id) {
            writer.println("player " + gameStatus.getWinner() + " has informed player " + id + " that player " + gameStatus.getWinner() + " has won");
            writer.println("player " + id + " exits");
            writer.println("player " + id + " hand: " + handToString());
            writer.flush();
        }
        writer.close();
    }

}
