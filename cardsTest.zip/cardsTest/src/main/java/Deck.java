package main.java;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.ReentrantLock;

public class Deck {
	private final int id;
    private final Queue<Card> cards;
    private final ReentrantLock lock = new ReentrantLock();

    public Deck(int id) {
        this.id = id;
        this.cards = new LinkedList<>();
    }

    public int getId() {
        return id;
    }

    public ReentrantLock getLock() {
        return lock;
    }

    public Card drawCard() {
        lock.lock();
        try {
            return cards.poll(); // Returns null if empty (handle accordingly)
        } finally {
            lock.unlock();
        }
    }

    public void addCard(Card card) {
        lock.lock();
        try {
            cards.offer(card);
        } finally {
            lock.unlock();
        }
    }

    public String getContents() {
        // Build string of remaining card values
        StringBuilder sb = new StringBuilder();
        for(Card card : cards) {
            sb.append(card).append(" ");
        }
        return sb.toString().trim();
    }

    public void addInitialCard(Card card) {
        cards.offer(card);
    }

}
