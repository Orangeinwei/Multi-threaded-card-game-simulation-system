package main.java;

import java.util.*;
import java.io.*;

public class CardGame {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get the number of players from the user.
        int numPlayers = 0;
        while (true) {
            System.out.println("Please enter the number of players:");
            String input = scanner.nextLine();
            try {
                numPlayers = Integer.parseInt(input);
                if (numPlayers > 0) {
                    break;
                } else {
                    System.out.println("Number of players must be a positive integer.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid number. Try again.");
            }
        }

        // Read the pack file (which must contain exactly 8 * numPlayers numbers).
        List<Integer> packValues = null;
        while (packValues == null) {
            System.out.println("Please enter location of pack to load:");
//            System.out.println("Working Directory = " + System.getProperty("user.dir"));

            String filePath = scanner.nextLine();
            packValues = readPackFile(filePath, numPlayers);
            if (packValues == null) {
                System.out.println("Invalid pack file. Please try again.");
            }
        }

        // Create decks (n decks, numbered 1 to n).
        List<Deck> decks = new ArrayList<>();
        for (int i = 1; i <= numPlayers; i++) {
            decks.add(new Deck(i));
        }

        // Prepare to store each player’s initial hand.
        List<List<Card>> playerHands = new ArrayList<>();
        for (int i = 0; i < numPlayers; i++) {
            playerHands.add(new ArrayList<>());
        }

        // Distribute the first 4*n cards to players in a round-robin fashion.
        int index = 0;
        for (int i = 0; i < 4 * numPlayers; i++) {
            int playerIndex = i % numPlayers;
            Card card = new Card(packValues.get(index++));
            playerHands.get(playerIndex).add(card);
        }

        // Distribute the remaining 4*n cards to decks in a round-robin fashion.
        for (int i = 0; i < 4 * numPlayers; i++) {
            int deckIndex = i % numPlayers;
            Card card = new Card(packValues.get(index++));
            decks.get(deckIndex).addInitialCard(card);
        }

        // Create a shared GameStatus object.
        GameStatus gameStatus = new GameStatus();

        // Create players and their output writers.
        List<Player> players = new ArrayList<>();
        List<Thread> playerThreads = new ArrayList<>();
        for (int i = 1; i <= numPlayers; i++) {
            int playerIndex = i - 1;
            // For player i, left deck is deck i.
            Deck leftDeck = decks.get(playerIndex);
            // Right deck is deck (i mod numPlayers): for the last player, this wraps to deck 1.
            Deck rightDeck = decks.get(playerIndex == numPlayers - 1 ? 0 : playerIndex + 1);

            PrintWriter writer = null;
            try {
                writer = new PrintWriter(new FileWriter("player" + i + "_output.txt"));
            } catch (IOException e) {
                System.out.println("Error creating output file for player " + i);
                e.printStackTrace();
            }

            Player player = new Player(i, leftDeck, rightDeck, writer, gameStatus);
            // Set the initial hand for this player.
            for (Card card : playerHands.get(playerIndex)) {
                player.addCardToHand(card);
            }
            players.add(player);
        }

        // Start each player thread.
        for (Player player : players) {
            Thread t = new Thread(player);
            playerThreads.add(t);
            t.start();
        }

        // Wait for all player threads to finish.
        for (Thread t : playerThreads) {
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Write deck output files.
        for (Deck deck : decks) {
            try (PrintWriter deckWriter = new PrintWriter(new FileWriter("deck" + deck.getId() + "_output.txt"))) {
                deckWriter.println("deck" + deck.getId() + " contents: " + deck.getContents());
            } catch (IOException e) {
                System.out.println("Error writing output for deck " + deck.getId());
                e.printStackTrace();
            }
        }

        scanner.close();
    }

    // Reads the pack file and returns a list of integers if valid.
    // The file must contain exactly 8 * numPlayers lines (each with a non-negative integer).
    private static List<Integer> readPackFile(String filePath, int numPlayers) {
        List<Integer> packValues = new ArrayList<>();
        int expectedCards = 8 * numPlayers;
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    try {
                        int value = Integer.parseInt(line);
                        if (value < 0) {
                            System.out.println("Negative card value encountered: " + value);
                            return null;
                        }
                        packValues.add(value);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid number in file: " + line);
                        return null;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + filePath);
            return null;
        }

        if (packValues.size() != expectedCards) {
            System.out.println("Pack file does not contain the expected number of cards. Expected "
                    + expectedCards + " but got " + packValues.size());
            return null;
        }
        return packValues;
    }

}
