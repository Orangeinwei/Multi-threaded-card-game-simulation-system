package test.java;

import main.java.GameStatus;
import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

public class GameStatusTest {
    
    private GameStatus gameStatus;
    
    @Before
    public void setUp() {
        gameStatus = new GameStatus();
    }
    
    @Test
    public void testInitialState() {
        assertFalse(gameStatus.isGameWon());
        assertEquals(-1, gameStatus.getWinner());
    }
    
    @Test
    public void testDeclareWinner() {
        gameStatus.declareWinner(3);
        assertTrue(gameStatus.isGameWon());
        assertEquals(3, gameStatus.getWinner());
    }
    
    @Test
    public void testFirstWinnerOnly() {
        gameStatus.declareWinner(3);
        gameStatus.declareWinner(5);
        assertEquals(3, gameStatus.getWinner()); // First winner should be kept
    }
}