package test.java;

import main.java.Card;  
import main.java.Deck;  
import main.java.Player;
import main.java.GameStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.After;
import java.io.PrintWriter;
import java.io.StringWriter;
import static org.junit.Assert.*;


public class PlayerTest {
    
    private Player player;
    private Deck leftDeck;
    private Deck rightDeck;
    private StringWriter stringWriter;
    private PrintWriter writer;
    private GameStatus gameStatus;
    
    @Before
    public void setUp() {
        leftDeck = new Deck(1);
        rightDeck = new Deck(2);
        gameStatus = new GameStatus();
        stringWriter = new StringWriter();
        writer = new PrintWriter(stringWriter);
        player = new Player(3, leftDeck, rightDeck, writer, gameStatus);
    }
    
    @After
    public void tearDown() {
        writer.close();
    }
    
    @Test
    public void testInitialHand() {
        player.addCardToHand(new Card(3));
        player.addCardToHand(new Card(3));
        player.addCardToHand(new Card(3));
        player.addCardToHand(new Card(3));
        
        // This should cause player to win immediately when run() is called
        Thread playerThread = new Thread(player);
        playerThread.start();
        try {
            playerThread.join(1000); // Wait for thread to finish
        } catch (InterruptedException e) {
            fail("Thread was interrupted");
        }
        
        assertTrue(gameStatus.isGameWon());
        assertEquals(3, gameStatus.getWinner());
        assertTrue(stringWriter.toString().contains("player 3 wins"));
    }
    
    @Test
    public void testCardSelection() {
        // Player 3 prefers 3s, so should discard non-3 cards first
        player.addCardToHand(new Card(3));
        player.addCardToHand(new Card(5));
        player.addCardToHand(new Card(7));
        player.addCardToHand(new Card(9));
        
        // Add a card to left deck for player to draw
        leftDeck.addCard(new Card(3));
        
        // Run one turn
        Thread playerThread = new Thread(player);
        playerThread.start();
        try {
            playerThread.join(1000);
        } catch (InterruptedException e) {
            fail("Thread was interrupted");
        }
        
        // Check that a non-3 card was discarded (should be in the right deck)
        Card discarded = rightDeck.drawCard();
        assertNotNull(discarded);
        assertNotEquals(3, discarded.getValue());
    }
}
