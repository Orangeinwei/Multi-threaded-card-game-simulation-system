package test.java;

import main.java.CardGame;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import static org.junit.Assert.*;

public class CardGameTest {
    
    private File testPackFile;
    
    @Before
    public void setUp() throws Exception {
        // Create a test pack file with 32 cards (for 4 players)
        testPackFile = new File("test_pack.txt");
        PrintWriter writer = new PrintWriter(testPackFile);
        for (int i = 1; i <= 32; i++) {
            writer.println(i % 8); // Use values 0-7 repeatedly
        }
        writer.close();
    }
    
    @After
    public void tearDown() {
        testPackFile.delete();
        // Clean up output files
        for (int i = 1; i <= 4; i++) {
            new File("player" + i + "_output.txt").delete();
            new File("deck" + i + "_output.txt").delete();
        }
    }
    
    @Test
    public void testReadPackFile() throws Exception {
        // Use reflection to test private method
        java.lang.reflect.Method method = CardGame.class.getDeclaredMethod(
            "readPackFile", String.class, int.class);
        method.setAccessible(true);
        
        // Test with valid pack (for 4 players)
        java.util.List<Integer> result = 
            (java.util.List<Integer>) method.invoke(null, testPackFile.getPath(), 4);
        assertNotNull(result);
        assertEquals(32, result.size());
        
        // Test with invalid player count (should return null)
        result = (java.util.List<Integer>) method.invoke(null, testPackFile.getPath(), 5);
        assertNull(result);
    }
    
    @Test
    public void testCompleteGameExecution() throws Exception {
        // Set up input stream with predefined inputs
        String input = "4\n" + testPackFile.getPath() + "\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        // Run the game
        CardGame.main(new String[0]);
        
        // Verify output files were created
        for (int i = 1; i <= 4; i++) {
            assertTrue(Files.exists(Paths.get("player" + i + "_output.txt")));
            assertTrue(Files.exists(Paths.get("deck" + i + "_output.txt")));
        }
        
        // Use GameFlowValidator to validate game correctness
        ByteArrayInputStream savedIn = new ByteArrayInputStream(new byte[0]);
        System.setIn(savedIn);
        GameFlowValidatorSorted.main(new String[0]);
    }
}