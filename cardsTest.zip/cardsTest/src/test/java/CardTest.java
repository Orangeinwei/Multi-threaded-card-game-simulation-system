package test.java;

import static org.junit.Assert.*;
import org.junit.Test;
import main.java.Card;


public class CardTest {
	@Test
    public void testCardCreation() {
        Card card = new Card(5);
        assertEquals(5, card.getValue());
    }
    
    @Test
    public void testToString() {
        Card card = new Card(7);
        assertEquals("7", card.toString());
    }

}
