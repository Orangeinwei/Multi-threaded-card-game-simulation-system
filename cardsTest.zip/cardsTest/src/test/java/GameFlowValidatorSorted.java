package test.java;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class GameFlowValidatorSorted {
	public static void main(String[] args) {
        int numPlayers = 4; // Adjust if needed.
        boolean valid = true;
        int winDeclarations = 0;

        // Validate each player's output file.
        for (int i = 1; i <= numPlayers; i++) {
            String fileName = "player" + i + "_output.txt";
            List<String> lines = readAllLines(fileName);
            if (lines == null || lines.size() < 3) {
                System.out.println("Error: " + fileName + " is missing or too short.");
                valid = false;
                continue;
            }

            // Parse initial hand from the first line.
            List<Integer> simulatedHand = new ArrayList<>();
            String initialLine = lines.get(0).trim(); // e.g., "player 1 initial hand 1 2 5 7"
            String[] tokens = initialLine.split("\\s+");
            if (tokens.length < 5) {
                System.out.println("Error: " + fileName + " initial hand line is invalid.");
                valid = false;
                continue;
            }
            for (int j = 4; j < tokens.length; j++) {
                try {
                    simulatedHand.add(Integer.parseInt(tokens[j]));
                } catch (NumberFormatException e) {
                    System.out.println("Error parsing initial hand card in " + fileName);
                    valid = false;
                }
            }

            // Process each group of lines (draw, discard, current hand).
            // We assume the log records actions in groups:
            //   draw line, discard line, current hand line.
            for (int j = 1; j < lines.size(); j++) {
                String line = lines.get(j).trim();

                // Count win declarations
                if (line.contains("wins")) {
                    winDeclarations++;
                }

                // Check for a draw action.
                if (line.startsWith("player " + i + " draws a")) {
                    // Example: "player 1 draws a 2 from deck 1"
                    String[] parts = line.split("\\s+");
                    int drawnCard;
                    try {
                        drawnCard = Integer.parseInt(parts[4]);
                    } catch (NumberFormatException e) {
                        System.out.println("Error parsing draw value in " + fileName);
                        valid = false;
                        continue;
                    }
                    simulatedHand.add(drawnCard);

                    // Next line should be a discard action.
                    j++;
                    if (j >= lines.size()) {
                        System.out.println("Error: Unexpected end of file after draw in " + fileName);
                        valid = false;
                        break;
                    }
                    String discardLine = lines.get(j).trim();
                    if (!discardLine.startsWith("player " + i + " discards a")) {
                        System.out.println("Error: Expected discard action after draw in " + fileName);
                        valid = false;
                        break;
                    }
                    // Example: "player 1 discards a 7 to deck 2"
                    String[] discardParts = discardLine.split("\\s+");
                    int discardCard;
                    try {
                        discardCard = Integer.parseInt(discardParts[4]);
                    } catch (NumberFormatException e) {
                        System.out.println("Error parsing discard value in " + fileName);
                        valid = false;
                        continue;
                    }
                    // Remove one occurrence of the discarded card.
                    boolean removed = simulatedHand.remove((Integer) discardCard);
                    if (!removed) {
                        System.out.println("Error: Discarded card " + discardCard + " not found in simulated hand for " + fileName);
                        valid = false;
                    }

                    // Next line should report the current hand.
                    j++;
                    if (j >= lines.size()) {
                        System.out.println("Error: Unexpected end of file after discard in " + fileName);
                        valid = false;
                        break;
                    }
                    String currentHandLine = lines.get(j).trim();
                    if (!currentHandLine.startsWith("player " + i + " current hand is")) {
                        System.out.println("Error: Expected current hand line after discard in " + fileName);
                        valid = false;
                        break;
                    }
                    // Parse the current hand from the log.
                    String[] currentParts = currentHandLine.split("\\s+");
                    List<Integer> loggedHand = new ArrayList<>();
                    for (int k = 5; k < currentParts.length; k++) {
                        try {
                            loggedHand.add(Integer.parseInt(currentParts[k]));
                        } catch (NumberFormatException e) {
                            System.out.println("Error parsing current hand card in " + fileName);
                            valid = false;
                        }
                    }

                    // Compare the simulated hand with the logged hand after sorting.
                    List<Integer> sortedSimulated = new ArrayList<>(simulatedHand);
                    List<Integer> sortedLogged = new ArrayList<>(loggedHand);
                    Collections.sort(sortedSimulated);
                    Collections.sort(sortedLogged);
                    if (!sortedSimulated.equals(sortedLogged)) {
                        System.out.println("Mismatch in hand for " + fileName);
                        System.out.println("Simulated hand (sorted): " + sortedSimulated);
                        System.out.println("Logged hand (sorted): " + sortedLogged);
                        valid = false;
                    }
                }

                // If the line indicates a win or exit, stop processing further actions.
                if (line.contains("wins") || line.contains("exits")) {
                    break;
                }
            }

            // Verify final hand matches.
            String finalLine = lines.get(lines.size() - 1).trim();
            if (finalLine.startsWith("player " + i + " final hand:")) {
                String[] finalTokens = finalLine.split("\\s+");
                List<Integer> finalLoggedHand = new ArrayList<>();
                for (int k = 4; k < finalTokens.length; k++) {
                    try {
                        finalLoggedHand.add(Integer.parseInt(finalTokens[k]));
                    } catch (NumberFormatException e) {
                        // Skip tokens that are not numbers.
                    }
                }
                List<Integer> sortedSimulated = new ArrayList<>(simulatedHand);
                List<Integer> sortedFinalLogged = new ArrayList<>(finalLoggedHand);
                Collections.sort(sortedSimulated);
                Collections.sort(sortedFinalLogged);
                if (!sortedSimulated.equals(sortedFinalLogged)) {
                    System.out.println("Error: Final hand mismatch in " + fileName);
                    System.out.println("Simulated final hand (sorted): " + sortedSimulated);
                    System.out.println("Logged final hand (sorted): " + sortedFinalLogged);
                    valid = false;
                }
            }
        }

        // Check that exactly one win declaration occurred.
        if (winDeclarations != 1) {
            System.out.println("Error: Expected exactly one win declaration across all players but found " + winDeclarations);
            valid = false;
        }

        if (valid) {
            System.out.println("Game flow validation passed for all players.");
        } else {
            System.out.println("Game flow validation failed. See errors above.");
        }
    }

    private static List<String> readAllLines(String fileName) {
        try {
            return Files.readAllLines(Paths.get(fileName));
        } catch (IOException e) {
            System.out.println("Error reading file " + fileName + ": " + e.getMessage());
            return null;
        }
    }

}