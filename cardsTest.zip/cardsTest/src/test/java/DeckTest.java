package test.java;

import main.java.Card;  
import main.java.Deck;  
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class DeckTest {
    
    private Deck deck;
    
    @Before
    public void setUp() {
        deck = new Deck(1);
    }
    
    @Test
    public void testNewDeckIsEmpty() {
        assertNull(deck.drawCard()); // Empty deck should return null on draw
    }
    
    @Test
    public void testAddAndDrawCard() {
        Card card = new Card(5);
        deck.addCard(card);
        Card drawn = deck.drawCard();
        assertEquals(5, drawn.getValue());
        assertNull(deck.drawCard()); // Should be empty again
    }
    
    @Test
    public void testGetContents() {
        deck.addInitialCard(new Card(3));
        deck.addInitialCard(new Card(7));
        assertEquals("3 7", deck.getContents());
    }
    
    @Test
    public void testMultipleCardsInOrder() {
        deck.addInitialCard(new Card(1));
        deck.addInitialCard(new Card(2));
        deck.addInitialCard(new Card(3));
        
        assertEquals(1, deck.drawCard().getValue());
        assertEquals(2, deck.drawCard().getValue());
        assertEquals(3, deck.drawCard().getValue());
    }
}